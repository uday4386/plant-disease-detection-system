import React from 'react';
import { AlertTriangle, CheckCircle } from 'lucide-react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

// Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

interface ResultsPanelProps {
  results: {
    className: string;
    probability: number;
    diseaseInfo?: {
      name: string;
      description: string;
      symptoms: string[];
      treatments: string[];
      preventions: string[];
    };
  }[];
}

const ResultsPanel: React.FC<ResultsPanelProps> = ({ results }) => {
  // Sort results by probability (highest first)
  const sortedResults = [...results].sort((a, b) => b.probability - a.probability);
  const topResult = sortedResults[0];
  
  // Prepare data for the chart
  const chartData = {
    labels: sortedResults.map(r => r.className),
    datasets: [
      {
        data: sortedResults.map(r => r.probability * 100),
        backgroundColor: [
          '#4CAF50', // Green for top result
          '#FFC107', // Yellow
          '#FF9800', // Orange
          '#F44336', // Red
          '#9C27B0', // Purple
        ],
        borderColor: '#FFFFFF',
        borderWidth: 2,
      },
    ],
  };
  
  const chartOptions = {
    plugins: {
      legend: {
        position: 'bottom' as const,
      },
    },
    cutout: '65%',
  };

  const isHealthy = topResult.className.toLowerCase().includes('healthy');

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden mb-8">
      <div className="p-6">
        <h2 className="text-2xl font-bold text-green-800 mb-4">Analysis Results</h2>
        
        <div className="flex flex-col md:flex-row gap-6">
          <div className="md:w-1/2">
            <div className={`p-4 rounded-lg mb-6 ${isHealthy ? 'bg-green-100' : 'bg-amber-100'}`}>
              <div className="flex items-center mb-2">
                {isHealthy ? (
                  <CheckCircle className="w-6 h-6 text-green-600 mr-2" />
                ) : (
                  <AlertTriangle className="w-6 h-6 text-amber-600 mr-2" />
                )}
                <h3 className="text-lg font-semibold">
                  {isHealthy ? 'Plant appears healthy' : 'Disease detected'}
                </h3>
              </div>
              <p className="text-gray-700">
                {isHealthy 
                  ? 'Good news! Your plant appears to be healthy. Continue with regular care.'
                  : `We've detected ${topResult.className} with ${(topResult.probability * 100).toFixed(1)}% confidence.`
                }
              </p>
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-2">Diagnosis Details</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700 mb-4">
                  {topResult.diseaseInfo?.description || 
                    "This appears to be " + topResult.className + ". The model has identified specific visual patterns associated with this condition."}
                </p>
                
                {topResult.diseaseInfo?.symptoms && (
                  <div className="mb-4">
                    <h4 className="font-medium text-gray-800 mb-1">Common Symptoms:</h4>
                    <ul className="list-disc list-inside text-gray-700">
                      {topResult.diseaseInfo.symptoms.map((symptom, index) => (
                        <li key={index}>{symptom}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="md:w-1/2">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-2">Confidence Levels</h3>
              <div className="bg-gray-50 p-4 rounded-lg flex justify-center">
                <div className="w-64 h-64">
                  <Doughnut data={chartData} options={chartOptions} />
                </div>
              </div>
            </div>
            
            {!isHealthy && topResult.diseaseInfo && (
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Treatment Recommendations</h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  {topResult.diseaseInfo.treatments && (
                    <ul className="list-disc list-inside text-gray-700 mb-4">
                      {topResult.diseaseInfo.treatments.map((treatment, index) => (
                        <li key={index}>{treatment}</li>
                      ))}
                    </ul>
                  )}
                  
                  {topResult.diseaseInfo.preventions && (
                    <div>
                      <h4 className="font-medium text-gray-800 mb-1">Prevention Tips:</h4>
                      <ul className="list-disc list-inside text-gray-700">
                        {topResult.diseaseInfo.preventions.map((prevention, index) => (
                          <li key={index}>{prevention}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsPanel;