import React from 'react';
import { BookOpen, Leaf, AlertTriangle, Lightbulb } from 'lucide-react';

const InfoPanel: React.FC = () => {
  return (
    <div className="container mx-auto p-4">
      <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div className="p-6">
          <h2 className="text-2xl font-bold text-green-800 mb-4">About Plant Disease Detection</h2>
          
          <div className="mb-8">
            <div className="flex items-center mb-3">
              <BookOpen className="w-6 h-6 text-green-600 mr-2" />
              <h3 className="text-xl font-semibold text-gray-800">How It Works</h3>
            </div>
            <p className="text-gray-700 mb-4">
              Our plant disease detection system uses deep learning technology to identify various plant diseases from images. 
              The system is trained on a dataset of thousands of plant images with different diseases and can recognize patterns 
              that indicate specific plant health issues.
            </p>
            <p className="text-gray-700">
              When you upload an image, our AI model analyzes it and compares the visual patterns against known disease 
              signatures. The system then provides a diagnosis along with confidence levels and treatment recommendations.
            </p>
          </div>
          
          <div className="mb-8">
            <div className="flex items-center mb-3">
              <Leaf className="w-6 h-6 text-green-600 mr-2" />
              <h3 className="text-xl font-semibold text-gray-800">Supported Plants</h3>
            </div>
            <p className="text-gray-700 mb-4">
              Our current model can detect diseases in the following plants:
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {['Apple', 'Blueberry', 'Cherry', 'Corn', 'Grape', 'Peach', 'Pepper', 'Potato', 'Strawberry', 'Tomato'].map((plant) => (
                <div key={plant} className="bg-green-50 px-3 py-2 rounded-lg text-green-800">
                  {plant}
                </div>
              ))}
            </div>
          </div>
          
          <div className="mb-8">
            <div className="flex items-center mb-3">
              <AlertTriangle className="w-6 h-6 text-amber-500 mr-2" />
              <h3 className="text-xl font-semibold text-gray-800">Limitations</h3>
            </div>
            <p className="text-gray-700 mb-4">
              While our system is highly accurate, it has some limitations:
            </p>
            <ul className="list-disc list-inside text-gray-700 space-y-2">
              <li>The system works best with clear, well-lit images of individual leaves</li>
              <li>Some diseases may have similar visual symptoms and require additional testing</li>
              <li>Environmental factors can sometimes cause symptoms that resemble diseases</li>
              <li>The system is designed as a diagnostic aid and not a replacement for professional consultation</li>
            </ul>
          </div>
          
          <div>
            <div className="flex items-center mb-3">
              <Lightbulb className="w-6 h-6 text-amber-500 mr-2" />
              <h3 className="text-xl font-semibold text-gray-800">Tips for Best Results</h3>
            </div>
            <ul className="list-disc list-inside text-gray-700 space-y-2">
              <li>Take photos in natural daylight without flash</li>
              <li>Ensure the affected area is clearly visible and in focus</li>
              <li>Include both healthy and diseased parts of the plant for comparison</li>
              <li>Take multiple photos from different angles for more accurate diagnosis</li>
              <li>Clean the lens of your camera before taking photos</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <h2 className="text-2xl font-bold text-green-800 mb-4">About the Model</h2>
          <p className="text-gray-700 mb-4">
            This plant disease detection system uses a convolutional neural network (CNN) trained on the PlantVillage dataset. 
            The model was trained to recognize various plant diseases across different crop species.
          </p>
          <p className="text-gray-700 mb-4">
            The model architecture is based on MobileNet, which is optimized for mobile and web applications while maintaining 
            high accuracy. It has been converted to TensorFlow.js format to run directly in your browser, ensuring your images 
            stay on your device for privacy.
          </p>
          <p className="text-gray-700">
            The current model achieves approximately 96% accuracy on validation data, though real-world performance may vary 
            depending on image quality and environmental conditions.
          </p>
        </div>
      </div>
    </div>
  );
};

export default InfoPanel;