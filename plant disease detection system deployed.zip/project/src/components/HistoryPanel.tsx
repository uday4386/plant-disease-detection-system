import React, { useState } from 'react';
import { Calendar, ChevronDown, ChevronUp } from 'lucide-react';
import { HistoryItem } from '../types';

interface HistoryPanelProps {
  history: HistoryItem[];
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ history }) => {
  const [expandedItem, setExpandedItem] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedItem(expandedItem === id ? null : id);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  if (history.length === 0) {
    return (
      <div className="container mx-auto p-4">
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6 text-center">
            <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-700 mb-2">No History Yet</h2>
            <p className="text-gray-600">
              Your analysis history will appear here after you analyze plant images.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div className="p-6">
          <h2 className="text-2xl font-bold text-green-800 mb-4">Analysis History</h2>
          
          <div className="space-y-4">
            {history.map((item) => {
              const topResult = item.results[0];
              const isExpanded = expandedItem === item.id;
              const isHealthy = topResult.className.toLowerCase().includes('healthy');
              
              return (
                <div 
                  key={item.id} 
                  className="border rounded-lg overflow-hidden transition-all duration-200"
                >
                  <div 
                    className={`flex items-center p-4 cursor-pointer ${
                      isHealthy ? 'bg-green-50' : 'bg-amber-50'
                    }`}
                    onClick={() => toggleExpand(item.id)}
                  >
                    <div className="w-16 h-16 rounded-md overflow-hidden flex-shrink-0">
                      <img 
                        src={item.image} 
                        alt="Plant" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    <div className="ml-4 flex-grow">
                      <h3 className="font-medium text-gray-800">
                        {topResult.className}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {formatDate(item.date)}
                      </p>
                    </div>
                    
                    <div className="flex-shrink-0">
                      <span className="inline-block px-2 py-1 text-sm rounded-full mr-2 bg-white">
                        {(topResult.probability * 100).toFixed(0)}%
                      </span>
                      {isExpanded ? (
                        <ChevronUp className="w-5 h-5 text-gray-600" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-600" />
                      )}
                    </div>
                  </div>
                  
                  {isExpanded && (
                    <div className="p-4 bg-white border-t">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-medium text-gray-800 mb-2">Diagnosis</h4>
                          <p className="text-gray-700 mb-4">
                            {topResult.diseaseInfo?.description || 
                              `This appears to be ${topResult.className} with ${(topResult.probability * 100).toFixed(1)}% confidence.`}
                          </p>
                        </div>
                        
                        {!isHealthy && topResult.diseaseInfo && (
                          <div>
                            <h4 className="font-medium text-gray-800 mb-2">Treatment</h4>
                            {topResult.diseaseInfo.treatments && (
                              <ul className="list-disc list-inside text-gray-700">
                                {topResult.diseaseInfo.treatments.slice(0, 2).map((treatment, index) => (
                                  <li key={index}>{treatment}</li>
                                ))}
                              </ul>
                            )}
                          </div>
                        )}
                      </div>
                      
                      <div className="mt-4">
                        <h4 className="font-medium text-gray-800 mb-2">All Predictions</h4>
                        <div className="space-y-2">
                          {item.results.map((result, index) => (
                            <div key={index} className="flex justify-between items-center">
                              <span className="text-gray-700">{result.className}</span>
                              <div className="w-48 bg-gray-200 rounded-full h-2.5">
                                <div 
                                  className="bg-green-600 h-2.5 rounded-full" 
                                  style={{ width: `${result.probability * 100}%` }}
                                ></div>
                              </div>
                              <span className="text-gray-700 w-12 text-right">
                                {(result.probability * 100).toFixed(1)}%
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HistoryPanel;