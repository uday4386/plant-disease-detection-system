import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, X, Loader2 } from 'lucide-react';
import { analyzeImage } from '../utils/imageAnalysis';

interface ImageUploaderProps {
  onImageUpload: (imageDataUrl: string) => void;
  selectedImage: string | null;
  onAnalyze: (results: any) => void;
  isAnalyzing: boolean;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ 
  onImageUpload, 
  selectedImage, 
  onAnalyze,
  isAnalyzing
}) => {
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError(null);
    
    if (acceptedFiles.length === 0) {
      return;
    }
    
    const file = acceptedFiles[0];
    
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      onImageUpload(dataUrl);
    };
    reader.readAsDataURL(file);
  }, [onImageUpload]);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif']
    },
    maxFiles: 1
  });

  const handleAnalyze = async () => {
    if (!selectedImage) return;
    
    try {
      const predictions = await analyzeImage(selectedImage);
      onAnalyze(predictions);
    } catch (err) {
      console.error('Analysis error:', err);
      setError('Failed to analyze the image. Please try again.');
    }
  };

  const handleClearImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    onImageUpload('');
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden mb-8">
      <div className="p-6">
        <h2 className="text-2xl font-bold text-green-800 mb-4">Upload Plant Image</h2>
        
        <div 
          {...getRootProps()} 
          className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors
            ${isDragActive ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-green-400'}`}
        >
          <input {...getInputProps()} />
          
          {selectedImage ? (
            <div className="relative">
              <button 
                onClick={handleClearImage}
                className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <img 
                src={selectedImage} 
                alt="Selected plant" 
                className="max-h-80 mx-auto rounded-lg" 
              />
            </div>
          ) : (
            <div className="py-8">
              <Upload className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <p className="text-lg text-gray-700">
                {isDragActive ? 'Drop the image here' : 'Drag & drop a plant image, or click to select'}
              </p>
              <p className="text-sm text-gray-500 mt-2">
                Supported formats: JPG, PNG, GIF
              </p>
            </div>
          )}
        </div>
        
        {error && (
          <div className="mt-4 p-3 bg-red-100 text-red-700 rounded-lg">
            <p>{error}</p>
          </div>
        )}
        
        {selectedImage && (
          <div className="mt-6 text-center">
            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className={`px-6 py-3 rounded-lg text-white font-medium ${
                isAnalyzing 
                  ? 'bg-gray-400 cursor-not-allowed' 
                  : 'bg-green-600 hover:bg-green-700'
              } transition-colors`}
            >
              {isAnalyzing ? (
                <span className="flex items-center justify-center">
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Analyzing...
                </span>
              ) : (
                'Analyze Image'
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ImageUploader;