import React, { useState, useEffect } from 'react';
import { Leaf, Upload, History, Info, AlertCircle, Home, BarChart } from 'lucide-react';
import ImageUploader from './components/ImageUploader';
import ResultsPanel from './components/ResultsPanel';
import HistoryPanel from './components/HistoryPanel';
import InfoPanel from './components/InfoPanel';
import Navbar from './components/Navbar';
import { loadModel } from './utils/modelLoader';
import { HistoryItem } from './types';

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [modelLoaded, setModelLoaded] = useState(false);
  const [modelLoadError, setModelLoadError] = useState<string | null>(null);

  useEffect(() => {
    const initModel = async () => {
      try {
        await loadModel();
        setModelLoaded(true);
      } catch (error) {
        console.error('Failed to load model:', error);
        setModelLoadError('Failed to load the detection model. Please refresh the page or try again later.');
      }
    };

    initModel();
  }, []);

  const handleImageUpload = (imageDataUrl: string) => {
    setSelectedImage(imageDataUrl);
    setActiveTab('analyze');
  };

  const handleAnalyze = async (predictions: any) => {
    setIsAnalyzing(true);
    
    // Simulate analysis time (in a real app, this would be the actual model inference)
    setTimeout(() => {
      setResults(predictions);
      
      // Add to history
      if (selectedImage && predictions) {
        const newHistoryItem: HistoryItem = {
          id: Date.now().toString(),
          image: selectedImage,
          date: new Date().toISOString(),
          results: predictions,
        };
        
        setHistory(prev => [newHistoryItem, ...prev]);
      }
      
      setIsAnalyzing(false);
    }, 1500);
  };

  const renderContent = () => {
    if (!modelLoaded) {
      return (
        <div className="flex flex-col items-center justify-center h-[calc(100vh-5rem)] p-4">
          {modelLoadError ? (
            <div className="text-center">
              <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-red-600 mb-2">Model Loading Error</h2>
              <p className="text-gray-700">{modelLoadError}</p>
              <button 
                className="mt-4 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                onClick={() => window.location.reload()}
              >
                Refresh Page
              </button>
            </div>
          ) : (
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <h2 className="text-xl font-bold text-green-700 mb-2">Loading Plant Disease Detection Model</h2>
              <p className="text-gray-700">Please wait while we initialize the AI model...</p>
            </div>
          )}
        </div>
      );
    }

    switch (activeTab) {
      case 'home':
        return (
          <div className="flex flex-col items-center justify-center h-[calc(100vh-5rem)] p-4 bg-gradient-to-b from-green-50 to-white">
            <div className="max-w-3xl text-center">
              <div className="bg-green-100 p-3 rounded-full inline-block mb-6">
                <Leaf className="w-12 h-12 text-green-600" />
              </div>
              <h1 className="text-4xl font-bold text-green-800 mb-4">Plant Disease Detection</h1>
              <p className="text-xl text-gray-700 mb-8">
                Upload an image of a plant leaf to identify diseases and get treatment recommendations.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <FeatureCard 
                  icon={<Upload className="w-8 h-8 text-green-600" />}
                  title="Upload Image"
                  description="Take or upload a photo of the affected plant leaf"
                />
                <FeatureCard 
                  icon={<BarChart className="w-8 h-8 text-green-600" />}
                  title="AI Analysis"
                  description="Our model analyzes the image to detect diseases"
                />
                <FeatureCard 
                  icon={<Info className="w-8 h-8 text-green-600" />}
                  title="Get Results"
                  description="Receive diagnosis and treatment recommendations"
                />
              </div>
              <button 
                onClick={() => setActiveTab('analyze')}
                className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-lg font-medium"
              >
                Start Diagnosis
              </button>
            </div>
          </div>
        );
      case 'analyze':
        return (
          <div className="container mx-auto p-4">
            <ImageUploader 
              onImageUpload={handleImageUpload} 
              selectedImage={selectedImage}
              onAnalyze={handleAnalyze}
              isAnalyzing={isAnalyzing}
            />
            {results && (
              <ResultsPanel results={results} />
            )}
          </div>
        );
      case 'history':
        return <HistoryPanel history={history} />;
      case 'info':
        return <InfoPanel />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-grow">
        {renderContent()}
      </main>
      <footer className="bg-green-800 text-white p-4 text-center">
        <p>© 2025 Plant Disease Detection System | Powered by TensorFlow.js</p>
      </footer>
    </div>
  );
}

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
    <div className="mb-4">{icon}</div>
    <h3 className="text-lg font-semibold text-green-800 mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

export default App;