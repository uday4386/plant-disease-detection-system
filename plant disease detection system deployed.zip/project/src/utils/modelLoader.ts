import * as tf from '@tensorflow/tfjs';
import { diseaseDatabase } from './diseaseDatabase';

// Global variable to store the loaded model
let model: tf.LayersModel | null = null;

// Function to load the model
export const loadModel = async (): Promise<tf.LayersModel> => {
  if (model) {
    return model;
  }

  try {
    // In a real application, this would load a pre-trained model from a URL
    // For this demo, we'll create a simple model that returns mock predictions
    model = await createMockModel();
    return model;
  } catch (error) {
    console.error('Error loading model:', error);
    throw new Error('Failed to load the plant disease detection model');
  }
};

// Create a mock model for demonstration purposes
const createMockModel = async (): Promise<tf.LayersModel> => {
  // Create a simple sequential model
  const mockModel = tf.sequential();
  
  // Add a Conv2D layer
  mockModel.add(tf.layers.conv2d({
    inputShape: [224, 224, 3],
    filters: 16,
    kernelSize: 3,
    activation: 'relu',
  }));
  
  // Add a MaxPooling layer
  mockModel.add(tf.layers.maxPooling2d({
    poolSize: 2,
    strides: 2,
  }));
  
  // Add a Flatten layer
  mockModel.add(tf.layers.flatten());
  
  // Add a Dense layer
  mockModel.add(tf.layers.dense({
    units: 38, // Number of disease classes
    activation: 'softmax',
  }));
  
  // Compile the model
  mockModel.compile({
    optimizer: 'adam',
    loss: 'categoricalCrossentropy',
    metrics: ['accuracy'],
  });
  
  return mockModel;
};

// Function to get the class names
export const getClassNames = (): string[] => {
  return Object.keys(diseaseDatabase);
};

// Function to get disease info by class name
export const getDiseaseInfo = (className: string) => {
  return diseaseDatabase[className] || null;
};