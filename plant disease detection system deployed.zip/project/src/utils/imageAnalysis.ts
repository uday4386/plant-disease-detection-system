import * as tf from '@tensorflow/tfjs';
import { loadModel, getClassNames, getDiseaseInfo } from './modelLoader';

// Function to preprocess the image
const preprocessImage = async (imageUrl: string): Promise<tf.Tensor> => {
  // Load the image
  const image = new Image();
  image.src = imageUrl;
  
  // Wait for the image to load
  await new Promise((resolve) => {
    image.onload = resolve;
  });
  
  // Create a canvas to resize the image
  const canvas = document.createElement('canvas');
  canvas.width = 224;
  canvas.height = 224;
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }
  
  // Draw the image on the canvas (resizing it to 224x224)
  ctx.drawImage(image, 0, 0, 224, 224);
  
  // Get the image data from the canvas
  const imageData = ctx.getImageData(0, 0, 224, 224);
  
  // Convert the image data to a tensor
  const tensor = tf.browser.fromPixels(imageData)
    .toFloat()
    .div(tf.scalar(255)) // Normalize to [0, 1]
    .expandDims(0); // Add batch dimension
  
  return tensor;
};

// Function to analyze the image and return predictions
export const analyzeImage = async (imageUrl: string) => {
  try {
    // Load the model
    const model = await loadModel();
    
    // Preprocess the image
    const tensor = await preprocessImage(imageUrl);
    
    // Get class names
    const classNames = getClassNames();
    
    // For demo purposes, instead of using the actual model prediction
    // we'll generate mock predictions to simulate the model's output
    // In a real application, you would use: const predictions = model.predict(tensor);
    const mockPredictions = generateMockPredictions(classNames);
    
    // Process the predictions
    const results = processPredictions(mockPredictions, classNames);
    
    // Clean up the tensor
    tensor.dispose();
    
    return results;
  } catch (error) {
    console.error('Error analyzing image:', error);
    throw new Error('Failed to analyze the image');
  }
};

// Function to generate mock predictions for demonstration
const generateMockPredictions = (classNames: string[]): number[] => {
  // Generate random probabilities
  const randomProbs = Array.from({ length: classNames.length }, () => Math.random());
  
  // Normalize to sum to 1
  const sum = randomProbs.reduce((a, b) => a + b, 0);
  const normalizedProbs = randomProbs.map(p => p / sum);
  
  // Make one prediction significantly higher to simulate confidence
  const maxIndex = Math.floor(Math.random() * classNames.length);
  
  // Create the final probabilities
  const finalProbs = normalizedProbs.map((p, i) => 
    i === maxIndex ? 0.7 + (p * 0.3) : p * 0.3
  );
  
  return finalProbs;
};

// Function to process the predictions and return the results
const processPredictions = (predictions: number[], classNames: string[]) => {
  // Create an array of class names and probabilities
  const results = classNames.map((className, index) => ({
    className,
    probability: predictions[index],
    diseaseInfo: getDiseaseInfo(className),
  }));
  
  // Sort by probability (highest first)
  results.sort((a, b) => b.probability - a.probability);
  
  // Return the top 5 predictions
  return results.slice(0, 5);
};