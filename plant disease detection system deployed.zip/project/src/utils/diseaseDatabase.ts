export const diseaseDatabase: Record<string, {
  name: string;
  description: string;
  symptoms: string[];
  treatments: string[];
  preventions: string[];
}> = {
  'Apple___Apple_scab': {
    name: 'Apple Scab',
    description: 'Apple scab is a common disease of apple trees caused by the fungus Venturia inaequalis. It affects both leaves and fruit, causing dark, scabby lesions.',
    symptoms: [
      'Olive-green to brown spots on leaves',
      'Dark, scabby lesions on fruit',
      'Deformed fruit',
      'Premature leaf drop'
    ],
    treatments: [
      'Apply fungicides during the growing season',
      'Remove and destroy fallen leaves and infected fruit',
      'Prune the tree to improve air circulation'
    ],
    preventions: [
      'Plant resistant varieties',
      'Maintain good orchard sanitation',
      'Apply preventative fungicide sprays in early spring'
    ]
  },
  'Apple___Black_rot': {
    name: 'Black Rot',
    description: 'Black rot is a fungal disease caused by Botryosphaeria obtusa that affects apple trees. It can cause fruit rot, leaf spots, and cankers on branches.',
    symptoms: [
      'Circular purple spots on leaves',
      'Rotting fruit with concentric rings',
      'Sunken cankers on branches',
      'Mummified fruit that remains attached to the tree'
    ],
    treatments: [
      'Prune out diseased branches and cankers',
      'Apply fungicides during the growing season',
      'Remove mummified fruit from the tree'
    ],
    preventions: [
      'Maintain tree vigor with proper fertilization',
      'Prune trees regularly to improve air circulation',
      'Remove nearby wild apple trees that may harbor disease'
    ]
  },
  'Apple___Cedar_apple_rust': {
    name: 'Cedar Apple Rust',
    description: 'Cedar apple rust is caused by the fungus Gymnosporangium juniperi-virginianae. It requires both apple trees and cedar (juniper) trees to complete its life cycle.',
    symptoms: [
      'Bright orange-yellow spots on leaves',
      'Small yellow spots on fruit',
      'Tiny black dots in the center of leaf spots',
      'Premature leaf drop'
    ],
    treatments: [
      'Apply fungicides in early spring',
      'Remove nearby cedar trees if possible',
      'Maintain good air circulation around trees'
    ],
    preventions: [
      'Plant resistant apple varieties',
      'Avoid planting apple trees near cedar or juniper trees',
      'Apply preventative fungicide sprays'
    ]
  },
  'Apple___healthy': {
    name: 'Healthy Apple',
    description: 'This apple plant appears healthy with no visible signs of disease or pest damage.',
    symptoms: [
      'Vibrant green leaves',
      'No spots or lesions on leaves or fruit',
      'Good leaf density',
      'Normal fruit development'
    ],
    treatments: [
      'Continue regular maintenance',
      'Monitor for early signs of disease or pests',
      'Maintain proper watering and fertilization'
    ],
    preventions: [
      'Regular pruning to maintain air circulation',
      'Proper orchard sanitation',
      'Balanced fertilization program'
    ]
  },
  'Corn___Cercospora_leaf_spot': {
    name: 'Cercospora Leaf Spot',
    description: 'Cercospora leaf spot is a fungal disease that affects corn plants, causing distinctive leaf spots and potentially reducing yield.',
    symptoms: [
      'Rectangular lesions between leaf veins',
      'Tan to gray spots with reddish-brown borders',
      'Lesions that may merge to form larger blighted areas',
      'Lower leaves affected first, progressing upward'
    ],
    treatments: [
      'Apply appropriate fungicides',
      'Improve air circulation in the field',
      'Maintain proper plant nutrition'
    ],
    preventions: [
      'Plant resistant varieties',
      'Crop rotation with non-host plants',
      'Avoid overhead irrigation'
    ]
  },
  'Corn___Common_rust': {
    name: 'Common Rust',
    description: 'Common rust is caused by the fungus Puccinia sorghi and is characterized by rust-colored pustules on corn leaves.',
    symptoms: [
      'Small, circular to elongated pustules on both leaf surfaces',
      'Cinnamon-brown to rust-colored spores',
      'Pustules that turn dark brown to black as they age',
      'Severe infections causing leaf yellowing and death'
    ],
    treatments: [
      'Apply fungicides at first sign of disease',
      'Maintain balanced soil fertility',
      'Avoid excessive nitrogen fertilization'
    ],
    preventions: [
      'Plant resistant hybrids',
      'Early planting to avoid optimal conditions for rust development',
      'Proper crop rotation'
    ]
  },
  'Corn___Northern_Leaf_Blight': {
    name: 'Northern Leaf Blight',
    description: 'Northern leaf blight is a fungal disease caused by Exserohilum turcicum. It creates distinctive cigar-shaped lesions on corn leaves.',
    symptoms: [
      'Long, elliptical gray-green to tan lesions',
      'Lesions that develop dark areas of fungal sporulation',
      'Lesions that may coalesce to blight entire leaves',
      'Disease progression from lower to upper leaves'
    ],
    treatments: [
      'Apply foliar fungicides',
      'Maintain proper plant nutrition',
      'Reduce plant stress through proper irrigation'
    ],
    preventions: [
      'Plant resistant hybrids',
      'Crop rotation with non-host crops',
      'Tillage to reduce overwintering inoculum'
    ]
  },
  'Corn___healthy': {
    name: 'Healthy Corn',
    description: 'This corn plant appears healthy with no visible signs of disease or pest damage.',
    symptoms: [
      'Uniform green color',
      'No spots, streaks, or lesions on leaves',
      'Vigorous growth',
      'Normal tassel and ear development'
    ],
    treatments: [
      'Continue regular maintenance',
      'Monitor for early signs of disease or pests',
      'Maintain proper watering and fertilization'
    ],
    preventions: [
      'Crop rotation',
      'Balanced fertilization program',
      'Regular scouting for early disease detection'
    ]
  },
  'Tomato___Bacterial_spot': {
    name: 'Bacterial Spot',
    description: 'Bacterial spot is caused by Xanthomonas species and affects tomato leaves, stems, and fruit, creating spots that can lead to significant crop loss.',
    symptoms: [
      'Small, water-soaked spots on leaves that turn brown',
      'Spots with yellow halos',
      'Spots on fruit that start green and turn brown, scabby',
      'Defoliation in severe cases'
    ],
    treatments: [
      'Apply copper-based bactericides',
      'Remove and destroy infected plant material',
      'Avoid working with plants when wet'
    ],
    preventions: [
      'Use disease-free seeds and transplants',
      'Crop rotation',
      'Avoid overhead irrigation'
    ]
  },
  'Tomato___Early_blight': {
    name: 'Early Blight',
    description: 'Early blight is caused by the fungus Alternaria solani and is characterized by distinctive target-like spots on older leaves first.',
    symptoms: [
      'Dark brown spots with concentric rings (target-like)',
      'Yellowing around the spots',
      'Lower leaves affected first',
      'Stem lesions that are dark, sunken and may girdle the stem'
    ],
    treatments: [
      'Apply appropriate fungicides',
      'Remove lower infected leaves',
      'Maintain good air circulation'
    ],
    preventions: [
      'Crop rotation',
      'Stake plants for better air circulation',
      'Mulch to prevent soil splash'
    ]
  },
  'Tomato___Late_blight': {
    name: 'Late Blight',
    description: 'Late blight is a devastating disease caused by Phytophthora infestans, the same pathogen that caused the Irish potato famine.',
    symptoms: [
      'Large, dark brown patches on leaves',
      'White, fuzzy growth on undersides of leaves in humid conditions',
      'Dark, greasy-looking lesions on fruit',
      'Rapid plant collapse in severe cases'
    ],
    treatments: [
      'Apply fungicides preventatively',
      'Remove and destroy infected plants immediately',
      'Harvest healthy fruit as soon as possible'
    ],
    preventions: [
      'Plant resistant varieties',
      'Avoid overhead irrigation',
      'Provide good air circulation'
    ]
  },
  'Tomato___Leaf_Mold': {
    name: 'Leaf Mold',
    description: 'Leaf mold is caused by the fungus Passalora fulva and primarily affects tomato plants in high humidity environments.',
    symptoms: [
      'Yellow spots on upper leaf surfaces',
      'Olive-green to grayish-brown velvety growth on lower leaf surfaces',
      'Leaves that curl, wither and may drop',
      'Rarely affects stems or fruit'
    ],
    treatments: [
      'Apply appropriate fungicides',
      'Improve air circulation',
      'Reduce humidity in greenhouses'
    ],
    preventions: [
      'Plant resistant varieties',
      'Provide adequate spacing between plants',
      'Avoid wetting leaves when watering'
    ]
  },
  'Tomato___Septoria_leaf_spot': {
    name: 'Septoria Leaf Spot',
    description: 'Septoria leaf spot is caused by the fungus Septoria lycopersici and is one of the most common diseases of tomatoes.',
    symptoms: [
      'Small, circular spots with dark borders and gray centers',
      'Spots that may have yellow halos',
      'Lower leaves affected first',
      'Tiny black dots (pycnidia) in the center of spots'
    ],
    treatments: [
      'Apply fungicides at first sign of disease',
      'Remove and destroy infected leaves',
      'Maintain good air circulation'
    ],
    preventions: [
      'Crop rotation',
      'Mulch to prevent soil splash',
      'Avoid overhead irrigation'
    ]
  },
  'Tomato___Spider_mites': {
    name: 'Spider Mites',
    description: 'Spider mites are tiny arachnids that feed on plant cells, causing stippling on leaves and webbing in severe infestations.',
    symptoms: [
      'Fine yellow or white speckles on leaves (stippling)',
      'Webbing on undersides of leaves and between stems',
      'Bronzing or yellowing of leaves',
      'Leaf drop in severe cases'
    ],
    treatments: [
      'Apply insecticidal soap or horticultural oil',
      'Introduce predatory mites',
      'Spray plants with strong water stream to dislodge mites'
    ],
    preventions: [
      'Maintain proper plant hydration',
      'Increase humidity around plants',
      'Regular monitoring for early detection'
    ]
  },
  'Tomato___Target_Spot': {
    name: 'Target Spot',
    description: 'Target spot is caused by the fungus Corynespora cassiicola and affects tomato foliage, stems, and fruit.',
    symptoms: [
      'Circular brown spots with concentric rings',
      'Spots that may have yellow halos',
      'Spots on fruit that are sunken with concentric rings',
      'Severe leaf drop in advanced cases'
    ],
    treatments: [
      'Apply appropriate fungicides',
      'Remove and destroy infected plant parts',
      'Improve air circulation'
    ],
    preventions: [
      'Crop rotation',
      'Avoid overhead irrigation',
      'Stake plants for better air circulation'
    ]
  },
  'Tomato___healthy': {
    name: 'Healthy Tomato',
    description: 'This tomato plant appears healthy with no visible signs of disease or pest damage.',
    symptoms: [
      'Vibrant green leaves',
      'No spots or lesions',
      'Good leaf density',
      'Normal fruit development'
    ],
    treatments: [
      'Continue regular maintenance',
      'Monitor for early signs of disease or pests',
      'Maintain proper watering and fertilization'
    ],
    preventions: [
      'Crop rotation',
      'Proper spacing for air circulation',
      'Regular monitoring'
    ]
  }
};