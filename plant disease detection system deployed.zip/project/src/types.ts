export interface HistoryItem {
  id: string;
  image: string;
  date: string;
  results: any;
}

export interface DiseaseInfo {
  name: string;
  description: string;
  symptoms: string[];
  treatments: string[];
  preventions: string[];
}

export interface Prediction {
  className: string;
  probability: number;
  diseaseInfo?: DiseaseInfo;
}